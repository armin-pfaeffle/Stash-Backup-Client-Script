Stash-Backup-Client-Script
==========================

This simple script is for running [Stash Backup Client](https://marketplace.atlassian.com/plugins/com.atlassian.stash.backup.client) on a Windows computer. In my case, I wanted a script that is callable by a Windows task, so my server can run backup and notify me about the result.

## Functionality/Features

* Configurable script for running Stash Backup Client
* Waitung for Stash service to run
* Send notification mail afer finishing script (with log)
* Simple mail credential configuration

